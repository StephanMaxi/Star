package edu.gsu.csci5338.stargazer;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;

public class GridViewAdapter extends BaseAdapter {

    private Context mContext;
    public static String[] mThumbIds;
    public static String[] hdIDs = Nasa.getHD();


    public GridViewAdapter(Context c) {
        mContext = c;
    }

    public GridViewAdapter(Context c, String[] appLinks){
        mContext = c;
        mThumbIds = appLinks;
    }

    public int getCount() {
        return mThumbIds.length;
    }

    @Override
    public String getItem(int position) {
        return mThumbIds[position];
    }

    public String getHDItem(int position){
        return hdIDs[position];
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(480, 480));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(4, 8, 4, 8);
        } else {
            imageView = (ImageView) convertView;
        }
        String url = getItem(position);
        Picasso.get().load(url).placeholder(R.drawable.loader).fit().centerCrop().into(imageView);
        return imageView;
    }

}