package edu.gsu.csci5338.stargazer;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;

import java.io.InputStream;

public class FullImageActivity extends Activity {
    ImageView img;
    MediaPlayer mPlayer;
    Intent i;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_image);
        i = getIntent();
        int position = i.getExtras().getInt("id");
        GridViewAdapter imageAdapter = new GridViewAdapter(this);

        img = (ImageView) findViewById(R.id.imageView);

        String url = imageAdapter.getHDItem(position);
        new DownloadImage().execute(url);
        mPlayer = MediaPlayer.create(getApplicationContext(),R.raw.starsong);
        mPlayer.start();
        mPlayer.setLooping(true);

    }


    public void onDestroy() {

        mPlayer.stop();
        super.onDestroy();

    }


    private class DownloadImage extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... URL) {
            String imageURL = URL[0];
            Bitmap bitmap = null;
            try {
                InputStream input = new java.net.URL(imageURL).openStream();
                bitmap = BitmapFactory.decodeStream(input);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            img.setImageBitmap(result);
        }
    }
}