package edu.gsu.csci5338.stargazer;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class Nasa extends AppCompatActivity {

    private String TAG = Nasa.class.getSimpleName();
    private static String url = "https://api.nasa.gov/planetary/apod?api_key=90lFNb51J7PlnVq5anhVkXrmE8OeucMLUnNokmvZ&date=2019-0";
    ArrayList<HashMap<String, String>> URLs = new ArrayList<>();
    ArrayList<String> storageURL = new ArrayList<String>();
    ArrayList<String> storageHD = new ArrayList<String>();
    ArrayList<String> storageDesc = new ArrayList<String>();
    String[] appLinks;
    String[] descriptions;
    public static String[] hdLinks;
    GridViewAdapter gva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new getURLs().execute();
    }

    private class getURLs extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();

            Calendar calendar = Calendar.getInstance();
            int thisDay = calendar.get(Calendar.DAY_OF_MONTH);
            int thisMonth = calendar.get(Calendar.MONTH)+1;
            String thisCall;

            for (int i = 0; i < 30; i++){
                if (thisDay-i == 0){
                    thisDay = 30+i;
                    thisMonth--;
                }
                thisCall = url + thisMonth + "-" + (thisDay-i);

                String jsonStr = sh.makeServiceCall(thisCall);
                JSONObject jsonObj;

                Log.e(TAG, "Response from url: " + jsonStr);

                if (jsonStr != null) {
                    try {
                        jsonObj = new JSONObject(jsonStr);

                        String date = jsonObj.getString("date");
                        String explanation = jsonObj.getString("explanation");
                        String media_type = jsonObj.getString("media_type");
                        String normalurl = jsonObj.getString("url");
                        String hdurl = jsonObj.getString("hdurl");

                        HashMap<String, String> picture = new HashMap<>();

                        if (!media_type.equals("image") || normalurl.equals("")){
                            Log.e(TAG, "Yikes it looks like thats a youtube link");

                        } else {

                            if (jsonObj.has("hdurl") ) {
                                picture.put("date", date);
                                picture.put("explanation", explanation);
                                picture.put("mediatype", media_type);
                                picture.put("hdurl", hdurl);
                                picture.put("normalurl", normalurl);

                                URLs.add(picture);
                                storageURL.add(picture.get("normalurl"));
                                storageDesc.add(picture.get("explanation"));
                                storageHD.add(picture.get("hdurl"));
                            } else {
                                picture.put("date", date);
                                picture.put("explanation", explanation);
                                picture.put("mediatype", media_type);
                                picture.put("normalurl", normalurl);

                                URLs.add(picture);
                                storageURL.add(picture.get("normalurl"));
                                storageDesc.add(picture.get("explanation"));
                                storageHD.add(picture.get("normalurl"));
                            }
                        }

                    } catch (final JSONException e) {
                        Log.e(TAG, "Json parsing error: " + e.getMessage());
                    }
                } else {
                    Log.e(TAG, "Couldn't get json from server.");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Couldn't get json from server. Check LogCat",
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            }
            appLinks = storageURL.toArray(new String[storageURL.size()]);
            descriptions = storageDesc.toArray(new String[storageDesc.size()]);
            hdLinks = storageHD.toArray(new String[storageHD.size()]);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            setContentView(R.layout.activity_main);
            final GridView gridview = (GridView) findViewById(R.id.gridview);
            gva = new GridViewAdapter(getApplicationContext(), appLinks);
            gridview.setAdapter(gva);
            gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                    Intent i = new Intent(getApplicationContext(), FullImageActivity.class);
                    i.putExtra("id", position);
                    startActivity(i);
                }
            });
            super.onPostExecute(result);
        }

    }

    public static String[] getHD(){
        return hdLinks;
    }

}